import React, { Component } from 'react';

class DashboardPage extends Component {
  render() {
    return (
      <div>
        Dashboard
      </div>
    );
  }
}

export default DashboardPage;
